console.log('mod mint nft solana on');
var PNG = require('pngjs').PNG;
module.exports.mint_nft_solana = mint_nft_solana;

//minting the nft and sending it

//import { clusterApiUrl, Connection, Keypair, LAMPORTS_PER_SOL } from  "@solana/web3.js";
//import { createMint, getOrCreateAssociatedTokenAccount, mintTo, setAuthority, transfer } from  "@solana/spl-token";

const solanaWeb3 = require('@solana/web3.js');
//console.log(solanaWeb3);

const solanaSplToken = require('@solana/spl-token');

//console.log(solanaWeb3);

function inv ( a )
{
	return (255 - a);
}


function mint_nft_solana(im0)
{
	
console.log('in function mint_nft_solana');


(async () => {
	
	console.log('connection...');
  // Connect to cluster
  const connection = new solanaWeb3.Connection(solanaWeb3.clusterApiUrl("devnet"), "confirmed");

  // Generate a new wallet keypair and airdrop SOL
  const fromWallet = solanaWeb3.Keypair.generate();
  
	console.log("Here we generated new wallet and keypair for it:");
	console.log(fromWallet.publicKey.toBase58());
  
  const fromAirdropSignature = await connection.requestAirdrop(
    fromWallet.publicKey,
    solanaWeb3.LAMPORTS_PER_SOL
  );
  
 
console.log("Confirming airdrop...");
  // Wait for airdrop confirmation
  await connection.confirmTransaction(fromAirdropSignature);

	console.log("After success requested airdrop to this wallet");
	console.log("Now we create a new SPL token");
  // Create a new token 
  const mint = await solanaSplToken.createMint(
    connection, 
    fromWallet,            // Payer of the transaction
    fromWallet.publicKey,  // Account that will control the minting 
    null,                  // Account that will control the freezing of the token 
    0                      // Location of the decimal place 
  );
  console.log(mint);

  // Get the token account of the fromWallet Solana address. If it does not exist, create it.
  const fromTokenAccount = await solanaSplToken.getOrCreateAssociatedTokenAccount(
    connection,
    fromWallet,
    mint,
    fromWallet.publicKey
  );
  
  
  
console.log("After creating tokem account for our SPL token (see below)");
console.log(fromTokenAccount);
  
  
    // Minting 1 new token to the "fromTokenAccount" account we just returned/created.
  let signature = await solanaSplToken.mintTo(
    connection,
    fromWallet,               // Payer of the transaction fees 
    mint,                     // Mint for the account 
    fromTokenAccount.address, // Address of the account to mint to 
    fromWallet.publicKey,     // Minting authority
    1                         // Amount to mint 
  );

console.log("SIGNATURE of transaction of this minting: ");
console.log(signature);

  await solanaSplToken.setAuthority(
    connection,
    fromWallet,            // Payer of the transaction fees
    mint,                  // Account 
    fromWallet.publicKey,  // Current authority 
    0,                     // Authority type: "0" represents Mint Tokens 
    null                   // Setting the new Authority to null
  );
  
})();






	var w = im0.width;
	var h = im0.height;
	
	
	var im = new PNG ( {
			
				width: w,
				height: h,
				filterType: 4
		} );
		
				
	
			

			for (var y = 0; y < h; y++) {
		

			for (var x = 0; x < w; x++) {
				
					
					var idx = (w * y + x) << 2;
					
					var new_idx = idx;
					
					im.data[new_idx] =   inv ( im0.data[idx] );
					im.data[new_idx+1] =  inv ( im0.data[idx+1] );
					im.data[new_idx+2] =  inv ( im0.data[idx+2] );
					im.data[new_idx+3] =  255;
					
					
					
					
				}
			}

	//	for png image // upload https://solanacookbook.com/references/nfts.html#upload-to-arweave or
	
	/**************
	
	import fs from "fs";
import Arweave from "arweave";

(async () => {
  const arweave = Arweave.init({
    host: "arweave.net",
    port: 443,
    protocol: "https",
    timeout: 20000,
    logging: false,
  });

  // Upload image to Arweave
  const data = fs.readFileSync("./code/nfts/arweave-upload/lowres-dog.png");

  const transaction = await arweave.createTransaction({
    data: data,
  });

  transaction.addTag("Content-Type", "image/png");

  const wallet = JSON.parse(fs.readFileSync("wallet.json", "utf-8"))
  
  await arweave.transactions.sign(transaction, wallet);

  const response = await arweave.transactions.post(transaction);
  console.log(response);

  const id = transaction.id;
  const imageUrl = id ? `https://arweave.net/${id}` : undefined;
  console.log("imageUrl", imageUrl);

  // Upload metadata to Arweave

  const metadata = {
    name: "Custom NFT #1",
    symbol: "CNFT",
    description: "A description about my custom NFT #1",
    seller_fee_basis_points: 500,
    external_url: "https://www.customnft.com/",
    attributes: [
      {
        trait_type: "NFT type",
        value: "Custom",
      },
    ],
    collection: {
      name: "Test Collection",
      family: "Custom NFTs",
    },
    properties: {
      files: [
        {
          uri: imageUrl,
          type: "image/png",
        },
      ],
      category: "image",
      maxSupply: 0,
      creators: [
        {
          address: "CBBUMHRmbVUck99mTCip5sHP16kzGj3QTYB8K3XxwmQx",
          share: 100,
        },
      ],
    },
    image: imageUrl,
  };

  const metadataRequest = JSON.stringify(metadata);

  const metadataTransaction = await arweave.createTransaction({
    data: metadataRequest,
  });

  metadataTransaction.addTag("Content-Type", "application/json");

  await arweave.transactions.sign(metadataTransaction, wallet);

  console.log("metadata txid", metadataTransaction.id);

  console.log(await arweave.transactions.post(metadataTransaction));
})();
	
	****************/
	

			return im;







}